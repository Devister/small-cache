package kubeless

import (
	"fmt"
	"git.aimap.io/go/logs"
)

func show() {
	fmt.Println("this is show")
	logs.Info("this is git.aimap.io log")
}
