package kubeless

import "fmt"

func show() {
	fmt.Println("this is show")
}
