package kubeless

import "github.com/kubeless/kubeless/pkg/functions"

func Hello(event functions.Event, context functions.Context) (string, error) {
	show()
	return "show complete", nil
}
